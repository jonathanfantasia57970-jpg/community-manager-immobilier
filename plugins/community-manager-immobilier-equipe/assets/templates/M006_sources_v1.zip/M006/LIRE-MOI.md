# M006 — Vrai / faux expliqué

Version 1 · 31 octobre 2026

Examiner une affirmation puis expliquer la nuance et l’action utile.

## Fichiers

Les SVG sont les sources modifiables : textes en calques, formes vectorielles et emplacements photo. Les PNG sont des aperçus au même format ; ne pas publier les champs entre accolades. Ouvrir un SVG dans un éditeur vectoriel compatible, modifier les textes et couleurs, remplacer les emplacements, puis exporter le format utile. L’édition native dans Canva n’est pas garantie. Police de repli : DejaVu Sans / Arial / sans-serif ; adapter à la charte.

## Séquence

1. {Vrai ou faux ?}
2. {Réponse et nuance}
3. {Le bon réflexe}

## Variables

affirmation, verdict nuancé, preuve actuelle, action

## Contrôle avant diffusion

Vérifier les faits, droits des médias, identité, lisibilité sur mobile, textes sans accolade, recadrage et mentions applicables. Le modèle ne vaut ni validation du contenu ni autorisation de publication.

Composition originale incluse pour les membres de l’équipe ; aucune photo ni marque tierce incluse. Ajouter uniquement des médias dont l’usage est autorisé.

Les canaux sont des usages possibles : ajuster dimensions, zone sûre et mode de publication. Un carrousel LinkedIn peut nécessiter un export PDF. Les SVG ne sont pas des templates Canva natifs.
